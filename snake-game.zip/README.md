# Snake Game 🐍

A simple Snake game built with HTML, CSS, and JavaScript.

## How to Play

- Use arrow keys to control the snake.
- Eat the red apple to grow.
- Avoid hitting walls or yourself.
- Your score will be shown when the game ends.

## Live Demo

You can upload this to GitHub Pages or run locally by opening `index.html` in your browser.
